package com.expense.tracker.entity;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="tbl_expenses")
public class Expense {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="expense_name")
	@NotBlank(message = "Expense name must not be null!!")
	@Size(min = 3,message = "Expense name should be more than 3 character")
	private String expensename;
	@Column(name="description")
	private String desc;
	@Column(name="expense_amount")
	@NotNull(message = "Expense amount must not be null")
	private BigDecimal amount;
	@NotBlank
	private String category;
	@NotNull(message = "Date must not be null")
	private Date date;
	
	@CreationTimestamp
	@Column(name="Created_datetime", nullable = false, updatable = false)
	private Timestamp createdAt;
	
	@UpdateTimestamp
	@Column(name="Updated_datetime")
	private Timestamp updatedAt;
}
