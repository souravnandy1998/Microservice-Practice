package com.expense.tracker.entity;

import java.util.Date;

import lombok.Data;

@Data
public class ErrorObject {

	private String msg;
	private int statuscode;
	private Date timestamp;
}
