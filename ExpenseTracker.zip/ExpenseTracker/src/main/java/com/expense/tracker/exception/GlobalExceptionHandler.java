package com.expense.tracker.exception;
import com.expense.tracker.entity.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(ResourcenotFoundException.class)
	public ResponseEntity<ErrorObject> ResourcenotFoundException(ResourcenotFoundException exp, WebRequest wr)
	{
		ErrorObject eo=new ErrorObject();
		eo.setStatuscode(HttpStatus.NOT_FOUND.value());
		eo.setMsg(exp.getMessage());
		eo.setTimestamp(new Date());
		return new ResponseEntity<ErrorObject>(eo,HttpStatus.NOT_FOUND);
		
	}
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ErrorObject> handleMethodargumentType(MethodArgumentTypeMismatchException exp, WebRequest wr)
	{
		ErrorObject eo=new ErrorObject();
		eo.setStatuscode(HttpStatus.BAD_REQUEST.value());
		eo.setMsg(exp.getMessage());
		eo.setTimestamp(new Date());
		return new ResponseEntity<ErrorObject>(eo,HttpStatus.BAD_REQUEST);
		
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorObject> handleGeneralException(Exception exp, WebRequest wr)
	{
		ErrorObject eo=new ErrorObject();
		eo.setStatuscode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		eo.setMsg(exp.getMessage());
		eo.setTimestamp(new Date());
		return new ResponseEntity<ErrorObject>(eo,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		
		Map<String,Object> body=new HashMap<String,Object>();
		body.put("timestap",new Date());
		body.put("status code", HttpStatus.BAD_REQUEST.value());
		List<String> errors=ex.getBindingResult().getFieldErrors().stream().map(x->x.getDefaultMessage()).collect(Collectors.toList());
		body.put("message", errors);
		
		return new ResponseEntity<Object>(body,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ItemAlreadyExistExpection.class)
	public ResponseEntity<ErrorObject> handleItemExistException(Exception exp, WebRequest wr)
	{
		ErrorObject eo=new ErrorObject();
		eo.setStatuscode(HttpStatus.CONFLICT.value());
		eo.setMsg(exp.getMessage());
		eo.setTimestamp(new Date());
		return new ResponseEntity<ErrorObject>(eo,HttpStatus.CONFLICT);
		
	}
	
}
