package com.expense.tracker.exception;

public class ResourcenotFoundException extends RuntimeException {

	public ResourcenotFoundException(String msg)
	{
		super(msg);
	}
}
