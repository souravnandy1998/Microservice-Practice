package com.expense.tracker.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.expense.tracker.entity.Expense;
import com.expense.tracker.exception.ResourcenotFoundException;
import com.expense.tracker.repos.ExpenseRepository;
import com.expense.tracker.service.ExpenseService;

@Service
public class ExpenseServiceImpl implements ExpenseService{

	@Autowired
	private ExpenseRepository expenseRepository;
	@Override
	public Page<Expense> getallExpenses(Pageable page) {
		// TODO Auto-generated method stub
		return expenseRepository.findAll(page);
	}
	@Override
	public Expense getExpenseById(Long id) throws ResourcenotFoundException {
		Optional<Expense> expense=expenseRepository.findById(id);
		if(expense.isPresent())
		{
			return expense.get();
		}
		throw new ResourcenotFoundException("Expense not present on this id "+id);
	}
	@Override
	public void deleteExpenseById(Long id) {
		Expense expense = getExpenseById(id);
		expenseRepository.delete(expense);		
	}
	
	@Override
	public Expense saveExpenseDetails(Expense exp) {
		return expenseRepository.save(exp);		
	}
	
	
	@Override
	public Expense updateExpenseDetails(Long id, Expense exp) {
		Expense existingexp=getExpenseById(id);
		existingexp.setExpensename(exp.getExpensename()!=null ? exp.getExpensename():existingexp.getExpensename());
		existingexp.setDesc(exp.getDesc()!=null ? exp.getDesc():existingexp.getDesc());
		existingexp.setAmount(exp.getAmount()!=null ? exp.getAmount():existingexp.getAmount());
		existingexp.setCategory(exp.getCategory()!=null ? exp.getCategory():existingexp.getCategory());
		existingexp.setDate(exp.getDate()!=null ? exp.getDate():existingexp.getDate());
		
		return expenseRepository.save(existingexp);
		
	}
	@Override
	public List<Expense> readByCategory(String category, Pageable page) {
		// TODO Auto-generated method stub
		return expenseRepository.findByCategory(category, page).toList();
	}
	@Override
	public List<Expense> readByName(String name, Pageable page) {
		// TODO Auto-generated method stub
		return expenseRepository.findByExpensenameContaining(name, page).toList();
	}
	@Override
	public List<Expense> readByDate(Date startDate, Date endDate, Pageable page) {
		if(startDate== null)
		{
			startDate= new Date(0);
		}
		if(endDate==null)
		{
			endDate=new Date(System.currentTimeMillis());
		}
		
		Page<Expense> pages=expenseRepository.findByDateBetween(startDate, endDate, page);
		return pages.toList();
	}
	

}
