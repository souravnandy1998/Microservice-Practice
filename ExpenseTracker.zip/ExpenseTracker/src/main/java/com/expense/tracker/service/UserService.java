package com.expense.tracker.service;

import com.expense.tracker.entity.User;
import com.expense.tracker.entity.UserModel;

public interface UserService {

	User createUser(UserModel user);
	
	User readUser(Long id);
	
	User updateuser(UserModel user,Long id);
	
	void delete(Long id);
}
