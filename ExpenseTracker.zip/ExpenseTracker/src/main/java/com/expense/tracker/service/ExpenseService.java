package com.expense.tracker.service;
import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.expense.tracker.entity.Expense;
public interface ExpenseService {

	Page<Expense> getallExpenses(Pageable page);
	
	Expense getExpenseById(Long id);
	
	Expense saveExpenseDetails(Expense exp);
	
	Expense updateExpenseDetails(Long id, Expense exp);
	
	void deleteExpenseById(Long id);
	
	List<Expense> readByCategory(String category,Pageable page);

	List<Expense> readByName(String name, Pageable page);
	
	List<Expense> readByDate(Date startDate, Date endDate, Pageable page);
}
