package com.expense.tracker.serviceImpl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.tracker.entity.User;
import com.expense.tracker.entity.UserModel;
import com.expense.tracker.exception.ItemAlreadyExistExpection;
import com.expense.tracker.exception.ResourcenotFoundException;
import com.expense.tracker.repos.UserRepository;
import com.expense.tracker.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User createUser(UserModel user) {
		if(userRepository.existsByEmail(user.getEmail()))
		{
			throw new ItemAlreadyExistExpection("User is already exist with this email "+user.getEmail());
		}
		
		User newuser=new User();
		BeanUtils.copyProperties(user, newuser);
		return userRepository.save(newuser);
	}
	
	
	@Override
	public User readUser(Long id) throws ResourcenotFoundException {
		// TODO Auto-generated method stub
		return userRepository.findById(id).orElseThrow(()-> new ResourcenotFoundException("User is not found with this id "+id));
		
	}


	@Override
	public User updateuser(UserModel user, Long id) throws ResourcenotFoundException {
		// TODO Auto-generated method stub
	
		User ouser=readUser(id);
		ouser.setName(user.getName()!=null ? user.getName():ouser.getName());
		ouser.setEmail(user.getEmail()!=null ? user.getEmail():ouser.getEmail());
		ouser.setPassword(user.getPassword()!=null ? user.getPassword():ouser.getPassword());
		ouser.setAge(user.getAge()!=null ? user.getAge():ouser.getAge());
		return userRepository.save(ouser);
	 
	 
	 
	}
	
	@Override
	public void delete(Long id) {
		User duser=readUser(id);
		userRepository.delete(duser);
		
	}

}
