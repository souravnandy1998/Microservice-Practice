package com.expense.tracker.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.expense.tracker.entity.Expense;
import com.expense.tracker.service.ExpenseService;
import com.expense.tracker.serviceImpl.ExpenseServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping
public class ExpenseController {
	
	@Autowired
	private ExpenseService expenseservice;

	@GetMapping("/expenses")
	public List<Expense> getallExpenses(Pageable page)
	{
		return expenseservice.getallExpenses(page).toList();
	}
	
	/*
	 * @GetMapping("/expenses/{id}") public String getExpenseFindbyId(@PathVariable
	 * Long id) { return "the espense id is "+id; }
	 */
	
	/*
	 * @GetMapping("/expenses") public String getExpenseFindbyId(@RequestParam Long
	 * id) { return "the expense id is "+id; }
	 */
	
	@GetMapping("/expense/{id}")
	public ResponseEntity<Expense> getExpenseById(@PathVariable Long id)
	{
		Expense exp=expenseservice.getExpenseById(id);		
		return ResponseEntity.ok(exp);	
	}
	
	@GetMapping("/expenses/category")
	public List<Expense> getExpensesbyCategory(@RequestParam String category, Pageable page)
	{
		return expenseservice.readByCategory(category, page);
	}
	
	@GetMapping("/expenses/expensename")
	public List<Expense> getExpensebyName(@RequestParam String name, Pageable page)
	{
		return expenseservice.readByCategory(name, page);
	}
	
	@GetMapping("/expenses/date")
	public List<Expense> getExpensebyDate(@RequestParam(required = false) Date startDate,@RequestParam(required = false) Date endDate, Pageable page)
	{
		return expenseservice.readByDate(startDate,endDate, page);
	}
	
	
	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping("/expenses")
	public Expense saveExpenseDetails(@Valid @RequestBody Expense exp)
	{
		return expenseservice.saveExpenseDetails(exp);
	}
	
	@PutMapping("/expenses/{id}")
	public Expense updateExpenseDetails(@Valid @RequestBody Expense exp, @PathVariable Long id)
	{
		return expenseservice.updateExpenseDetails(id, exp);
	}
	
	@DeleteMapping("/expenses/{id}")
	public void deleteExpenseById(@PathVariable Long id)
	{
		expenseservice.deleteExpenseById(id);
	}
}
