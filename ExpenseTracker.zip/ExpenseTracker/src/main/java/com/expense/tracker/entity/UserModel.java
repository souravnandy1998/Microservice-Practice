package com.expense.tracker.entity;

import org.hibernate.validator.constraints.NotBlank;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class UserModel {

	@NotBlank(message = "Please enter name")
	private String name;
	
	@NotNull(message = "Please enter email")
	@Email(message = "Please enter valid email")
	private String email;
	
	@NotNull(message = "Please enter password")
	@Size(min=5,message = "Password should be atleast 5 characters")
	private String password;
	
	private Long age=0L;

}
