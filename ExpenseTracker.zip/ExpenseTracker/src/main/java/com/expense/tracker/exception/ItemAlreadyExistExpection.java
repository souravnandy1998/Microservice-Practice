package com.expense.tracker.exception;


public class ItemAlreadyExistExpection extends RuntimeException {

	public ItemAlreadyExistExpection(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
