package com.expense.tracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.expense.tracker.entity.User;
import com.expense.tracker.entity.UserModel;
import com.expense.tracker.service.UserService;

import jakarta.validation.Valid;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping("/register")
	public ResponseEntity<User> createUser(@Valid @RequestBody UserModel user)
	{
		User createUser = userService.createUser(user);
		return new ResponseEntity<User>(createUser,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/users/{id}")
	public ResponseEntity<User> readUser(@PathVariable Long id)
	{
		User readUser = userService.readUser(id);
		return new ResponseEntity<User>(readUser,HttpStatus.OK);
	}
	
	@PutMapping("users/{id}")
	public ResponseEntity<User> updateUser(@RequestBody UserModel user,@PathVariable Long id)
	{
		User updateuser = userService.updateuser(user, id);
		return new ResponseEntity<User>(updateuser,HttpStatus.OK);
	}
	
	@DeleteMapping("users/{id}")
	public void deleteUser(@PathVariable Long id)
	{
		userService.delete(id);
	}
}