package com.question.service;

import java.util.List;

import com.question.entities.Question;

public interface QuestionService {

	public Question add(Question question);
	
	public List<Question> getallQuestion();
	
	public Question getbyId(long id);
	
	public List<Question> getquestionofQuiz(long quizId);
}
