package com.user.service.services.impl;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.user.service.entities.Hotel;
import com.user.service.entities.Rating;
import com.user.service.entities.User;
import com.user.service.exception.ResourceNotFoundException;
import com.user.service.external.services.HotelService;
import com.user.service.repositories.UserRepository;
import com.user.service.services.UserService;

import ch.qos.logback.classic.Logger;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private HotelService hotelService;
	
	private Logger logger=(Logger) LoggerFactory.getLogger(UserServiceImpl.class);
	
	
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		
		String randomUUID = UUID.randomUUID().toString();
		user.setUserId(randomUUID);
		return userRepository.save(user);
	}

	@Override
	public List<User> getallUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUser(String userId) {
		// TODO Auto-generated method stub
		User user= userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User id not found!!"+ userId));
		//http://localhost:8086/ratings/users/8eba29f5-a8a1-449e-aaf4-cd018fade102
		Rating[] ratingsofuser = restTemplate.getForObject("http://RATINGSERVICE/ratings/users/"+user.getUserId(),Rating[].class);
		logger.info("{}",ratingsofuser);
		
		List<Rating> ratings = Arrays.stream(ratingsofuser).toList();
		
		List<Rating> ratingList=ratings.stream().map(rating->{
			
//			  ResponseEntity<Hotel>
//			  forEntity=restTemplate.getForEntity("http://HOTELSERVICE/hotels/"+rating.
//			  getHotelId(), Hotel.class); 
//			Hotel hotel=forEntity.getBody();
//			  logger.info("Response Status Code:{}",forEntity.getStatusCode());
//			 
			Hotel hotel=hotelService.getHotel(rating.getHotelId());
			rating.setHotel(hotel);
			return rating;
			
		}
		).collect(Collectors.toList());
		
		user.setRatings(ratingList);
		return user;
	}

}
