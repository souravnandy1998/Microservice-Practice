package com.user.service.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.user.service.entities.User;

public interface UserService {

	User saveUser(User User);
	
	List<User> getallUser();
	
	User getUser(String userId);
}
