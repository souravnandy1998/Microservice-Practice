package com.hotel.service.services.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.hotel.service.HotelServiceApplication;
import com.hotel.service.entities.Hotel;
import com.hotel.service.exception.ResourceNotFoundException;
import com.hotel.service.repositories.HotelRepository;
import com.hotel.service.services.HotelService;

@Service
public class HotelServiceImpl implements HotelService{

	@Autowired
	HotelRepository hotelRepository;
	
	@Override
	public Hotel createHotel(Hotel hotel) {
		
		String hid = UUID.randomUUID().toString();
		hotel.setId(hid);
		return hotelRepository.save(hotel);
	}

	@Override
	public Hotel getHotelbyId(String id) {
		// TODO Auto-generated method stub
		return hotelRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Hotel id not found!!"+ id));
	}

	@Override
	public List<Hotel> allHotels() {
		// TODO Auto-generated method stub
		return hotelRepository.findAll();
	}

}
