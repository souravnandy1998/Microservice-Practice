package com.hotel.service.services;

import java.util.List;

import com.hotel.service.entities.Hotel;

public interface HotelService {

	Hotel createHotel(Hotel hotel);
	
	Hotel getHotelbyId(String id);
	
	List<Hotel> allHotels();
	
}
