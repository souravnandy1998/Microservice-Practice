package com.rating.service.services;

import java.util.List;
import com.rating.service.entities.Rating;

public interface RatingService {
	
	Rating saverating(Rating rating);
	
	List<Rating> getallRating();
	
	List<Rating> getRatingbyuserId(String userId);

	List<Rating> getRatingbyHotelId(String hotelId);
}
