package com.rating.service.services.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rating.service.entities.Rating;
import com.rating.service.repositories.RatingRepositories;
import com.rating.service.services.RatingService;

@Service
public class RatingServiceImpl implements RatingService {

	@Autowired
	private RatingRepositories ratingRepositories;
	
	@Override
	public Rating saverating(Rating rating) {		
		String id1 = UUID.randomUUID().toString();
		rating.setRatingId(id1);
		return ratingRepositories.save(rating);
	}

	@Override
	public List<Rating> getallRating() {
		
		return ratingRepositories.findAll();
	}

	@Override
	public List<Rating> getRatingbyuserId(String userId) {
		// TODO Auto-generated method stub
		return ratingRepositories.findByUserId(userId);
	}

	@Override
	public List<Rating> getRatingbyHotelId(String hotelId) {
		// TODO Auto-generated method stub
		return ratingRepositories.findByHotelId(hotelId);
	}

	
	

}
