package com.quiz.service.impl;
import com.quiz.entities.*;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url="http://localhost:8075",value = "Question-Client")
public interface QuestionClient {

	@GetMapping("/question/quiz/{quizid}")
	List<Question> getQuestionofQuiz(@PathVariable Long quizid);
	
}
